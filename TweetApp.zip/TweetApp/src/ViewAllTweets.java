import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ViewAllTweets {
    static final String query = "select * from tweetapp.tweets;";
    public static void viewAllTweets(){
        try{
            Connection conn = DBConnection.connectDB();
            PreparedStatement prep = conn.prepareStatement(query);
            ResultSet rs = prep.executeQuery();
            while(rs.next()){
                System.out.println(rs.getString("tweet"));
            }
        }catch (Exception e){
            System.out.println(e);
        }
    }
}
