import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ViewMyTweets {
    static final String query = "select * from tweetapp.tweets where email = ?;";
    public static void viewMyTweets(String email){
        try{
            Connection conn = DBConnection.connectDB();
            PreparedStatement prep = conn.prepareStatement(query);
            prep.setString(1,email);
            ResultSet rs = prep.executeQuery();
            while(rs.next()){
                System.out.println(rs.getString("tweet"));
            }
        }catch (Exception e){
            System.out.println(e);
        }
    }
}
