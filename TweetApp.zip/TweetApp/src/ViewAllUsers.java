import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ViewAllUsers {
    static final String query = "select * from tweetapp.registration;";
    public static void viewAllUsers(){
        try{
            Connection conn = DBConnection.connectDB();
            PreparedStatement prep = conn.prepareStatement(query);
            ResultSet rs = prep.executeQuery();
            while(rs.next()){
                System.out.println("Name : "+rs.getString("first_name"));
                System.out.println("email : "+rs.getString("email"));
            }
        }catch (Exception e){
            System.out.println(e);
        }
    }
}
