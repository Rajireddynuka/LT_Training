import java.util.Scanner;

public class TweetAppMain {
    public static void main(String[] args){

        Scanner in = new Scanner(System.in);
        while(true) {
        System.out.println("Select the operation which you want to perform:");
        System.out.println("Register : 1");
        System.out.println("Login : 2");
        System.out.println("Forgot Password : 3");
        int option = in.nextInt();

            switch (option) {
                case 1:
                    Registration.register();
                    break;

                case 2:
                    Login.login();
                    break;

                case 3:
                    UpdatePassword.forgotPassword();
                    break;

            }
        }
    }
}
