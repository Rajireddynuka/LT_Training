import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class Login {
    static final String query = "select * from tweetapp.registration where email = ? and password = ?;";
    public static void login(){
        try{
            Connection conn = DBConnection.connectDB();
            PreparedStatement prep = conn.prepareStatement(query);
            Scanner in = new Scanner(System.in);
            System.out.println("Enter email:");
            String email = in.next();
            System.out.println("Enter password:");
            String password = in.next();

            prep.setString(1,email);
            prep.setString(2,password);
            ResultSet rs = prep.executeQuery();
            boolean check = true;
            if(rs.next()){
                UpdateActveStatus.updateStatus(email,"Active");
                while(check) {
                    System.out.println(" Welcome " + rs.getString("first_name"));
                    System.out.println("Select the operation which you want to perform:");
                    System.out.println("Post a tweet : 1");
                    System.out.println("View my tweets : 2");
                    System.out.println("View all tweets : 3");
                    System.out.println("View all users : 4");
                    System.out.println("Reset password : 5");
                    System.out.println("Logout : 6");
                    int option = in.nextInt();

                    switch (option) {
                        case 1:
                            PostTweet.postTweet(email);
                            System.out.println("==========================================");
                            break;

                        case 2:
                            ViewMyTweets.viewMyTweets(email);
                            System.out.println("==========================================");
                            break;

                        case 3:
                            ViewAllTweets.viewAllTweets();
                            System.out.println("==========================================");
                            break;

                        case 4:
                            ViewAllUsers.viewAllUsers();
                            System.out.println("==========================================");
                            break;

                        case 5:
                            UpdatePassword.updatePassword(email);
                            System.out.println("==========================================");
                            break;

                        case 6:
                            UpdateActveStatus.updateStatus(email,"Inactive");
                            check=false;
                            System.out.println("==========================================");
                            break;


                    }
                }
            }
            else{
                System.out.println("Login failed");
            }


        }catch (Exception e){
            System.out.println(e);
        }
    }
}
