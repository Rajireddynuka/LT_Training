import java.sql.*;
import java.util.Scanner;

public class Retrive {

    static final String d_Url = "jdbc:mysql://localhost:3306/demo";
    static final String User = "root";
    static final String paswd = "pass@word1";
    static final String query = " select * from persons;";

    public static void main(String[] args){
        try {
            Connection conn = DriverManager.getConnection(d_Url,User,paswd);
            Statement stat = conn.createStatement();
            ResultSet rs = stat.executeQuery(query);
            while(rs.next()){
                System.out.println("Id : "+rs.getInt("PersonID"));
            }
        }
        catch (Exception e){

        }

    }
}
