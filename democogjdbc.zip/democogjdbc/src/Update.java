import java.sql.*;
import java.util.Scanner;

public class Update {
    static final String d_Url = "jdbc:mysql://localhost:3306/demo";
    static final String User = "root";
    static final String paswd = "pass@word1";
    static final String query2 = "update persons set Address = ? where PersonID = ?;";

    public static void main(String[] args){
        try {
            Connection conn = DriverManager.getConnection(d_Url,User,paswd);
            Statement stat = conn.createStatement();
            PreparedStatement prep = conn.prepareStatement(query2);
            Scanner in = new Scanner(System.in);
            System.out.println("Enter PersonID which need to update:");
            int id = in.nextInt();
         //   System.out.println("Select Field which has to be update LastName,FirstName,Address,City");
         //   String s1 = in.next();
            System.out.println("Enter Address : ");
            String s2 = in.next();
            prep.setInt(2,id);
           // prep.setString(1,s1);
            prep.setString(1,s2);
            prep.executeUpdate();

        }
        catch (Exception e){

        }

    }
}
