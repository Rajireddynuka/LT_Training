import java.sql.*;
import java.util.Scanner;

public class RetriveWithId {
    static final String d_Url = "jdbc:mysql://localhost:3306/demo";
    static final String User = "root";
    static final String paswd = "pass@word1";
    static final String query2 = "select * from persons where PersonID = ?;";

    public static void main(String[] args){
        try {
            Connection conn = DriverManager.getConnection(d_Url,User,paswd);
            Statement stat = conn.createStatement();
            PreparedStatement prep = conn.prepareStatement(query2);
            Scanner in = new Scanner(System.in);
            System.out.println("Enter PersonID:");
            int id = in.nextInt();

            prep.setInt(1,id);
            ResultSet rs = prep.executeQuery();
            while(rs.next()){
                System.out.println("Id : "+rs.getInt("PersonID")  + " PersonName : " + rs.getString("FirstName")+" "+rs.getString("LastName"));
            }


        }
        catch (Exception e){

        }

    }
}
