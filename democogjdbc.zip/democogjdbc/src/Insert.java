import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;
import java.sql.*;
import java.util.Scanner;

    public class Insert {

        static final String d_Url = "jdbc:mysql://localhost:3306/demo";
        static final String User = "root";
        static final String paswd = "pass@word1";
        static final String query2 = "insert into persons (PersonID,LastName,FirstName,Address,City) values(?,?,?,?,?);";

        public static void main(String[] args){
            try {
                Connection conn = DriverManager.getConnection(d_Url,User,paswd);
                Statement stat = conn.createStatement();
                PreparedStatement prep = conn.prepareStatement(query2);
                Scanner in = new Scanner(System.in);
                System.out.println("Enter PersonID:");
                int id = in.nextInt();
                System.out.println("Enter Lastname:");
                String s1 = in.next();
                System.out.println("Enter Firstname:");
                String s2 = in.next();
                System.out.println("Enter State:");
                String s3 = in.next();
                System.out.println("Enter City:");
                String s4 = in.next();

                prep.setInt(1,id);
                prep.setString(2,s1);
                prep.setString(3,s2);
                prep.setString(4,s3);
                prep.setString(5,s4);
                prep.executeUpdate();


            }
            catch (Exception e){

            }

        }

}
