import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.Scanner;

public class Delete {
    static final String d_Url = "jdbc:mysql://localhost:3306/demo";
    static final String User = "root";
    static final String paswd = "pass@word1";
    static final String query2 = "delete from persons where PersonID = ?;";

    public static void main(String[] args) {
        try {
            Connection conn = DriverManager.getConnection(d_Url, User, paswd);
            PreparedStatement prep = conn.prepareStatement(query2);
            Scanner in = new Scanner(System.in);
            System.out.println("Enter PersonID which need to delete:");
            int id = in.nextInt();

            prep.setInt(1, id);
            prep.executeUpdate();

        } catch (Exception e) {

        }
    }
}
