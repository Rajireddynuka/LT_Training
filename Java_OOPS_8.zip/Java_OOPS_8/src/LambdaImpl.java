import java.util.Arrays;
import java.util.List;

public class LambdaImpl {


    public static void main(String[] args){

        List<Integer> list = Arrays.asList(2,5,8,4,7,10);
        Lambda l1 = () -> System.out.println("In lambda method");
        l1.method1();

        list.stream().sorted().filter(n -> n%2 ==0).map(n -> n*n).forEach(System.out::println);

    }
}
