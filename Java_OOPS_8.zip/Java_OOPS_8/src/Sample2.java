public class Sample2 extends Sample{
        public void method1(){
            System.out.println("Inside abstract method");
        }
        public static void main(String[] args){
            Sample2 s2 = new Sample2();
            s2.method1();
            s2.method1("In implemented method of abstract class");
        }
}
