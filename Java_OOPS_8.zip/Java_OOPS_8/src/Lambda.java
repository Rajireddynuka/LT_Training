@FunctionalInterface
public interface Lambda {
    void method1();
}
