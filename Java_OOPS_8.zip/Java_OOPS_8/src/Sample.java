abstract public class Sample {
    abstract public void method1();
    public void method1(String s1){
        System.out.println(s1);
    }
}


